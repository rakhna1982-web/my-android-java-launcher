# CraftLauncher — Android Java engine build

This build configuration creates a real Android Minecraft: Java Edition launcher APK by building the open-source **Amethyst-Android** engine and applying CraftLauncher app-name/package branding.

It is a practical replacement for the earlier CraftLauncher 0.1 profile-manager prototype. The prototype's old UI/data are **not merged into this engine build**. This APK uses the Amethyst launcher screens and runtime. The app label is `CraftLauncher (Debug)` and the Android package ID is `com.craftlauncher.android.debug`.

## Build using only your phone

1. Upload the contents of this folder to the root of your GitHub repository. Make sure `.github/workflows/build-craftlauncher.yml` and `scripts/brand_amethyst.py` are included.
2. Open the repository's **Actions** tab.
3. Select **Build CraftLauncher (Android Java Engine)** and press **Run workflow**. A push to `main` also starts the build.
4. When the run has a green check, open it and download the `CraftLauncher-APK` artifact.
5. Extract the artifact ZIP on Android and install `CraftLauncher-debug.apk`.

The workflow checks out the upstream `v3_openjdk` branch recursively, sets up JDK 21 and Android SDK 37 / NDK 27.3.13750724, applies the branding script, and runs `:app_pojavlauncher:assembleDebug`.

## Java runtimes

The Amethyst engine includes a Java Runtime Manager. Its current Android changelog says JRE 17, 21 and 25 can be downloaded from the runtime manager; runtime downloads require internet. Install the runtime needed for your Minecraft version while online.

## Offline play and accounts

CraftLauncher supports the upstream launcher's legitimate offline workflow:

1. While connected to the internet, sign in with a Microsoft account that owns Minecraft: Java Edition.
2. Let the launcher verify the account, and download the Minecraft version, libraries, assets, mod loader and Java runtime you need.
3. After the ownership check, create/use a **Local/Offline** profile in the launcher's account screen.
4. You can then use the already-downloaded single-player installation without an internet connection. Multiplayer servers still need a connection.

The Local/Offline profile is not a way to bypass game ownership. This project does not add cracked/no-premium authentication, fake account tokens, or Microsoft-login bypasses. First login and all required downloads must happen online.

## Source and license

- Runtime/launcher engine: https://github.com/AngelAuraMC/Amethyst-Android (branch `v3_openjdk`)
- Build instructions and capabilities: https://github.com/AngelAuraMC/Amethyst-Android#building
- Amethyst is licensed under GNU LGPLv3. The workflow includes the upstream `LICENSE` file and exact source commit ID in the artifact. Keep these notices when sharing the APK.
- Minecraft is published by Mojang/Microsoft; CraftLauncher is an independent community project and is not affiliated with Mojang or Microsoft.

This repository contains the build workflow and a small branding patch, not a copy of all Amethyst source. The workflow downloads the upstream source at build time.
