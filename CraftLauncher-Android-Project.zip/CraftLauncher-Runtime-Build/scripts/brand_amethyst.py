#!/usr/bin/env python3
"""Apply CraftLauncher package/name branding to a fresh Amethyst checkout.

This deliberately changes only Android app identity strings. It does not alter
Microsoft authentication, ownership checks, runtime handling, or game code.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path


def replace_once(text: str, pattern: str, replacement: str, description: str) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise SystemExit(f"Could not safely patch {description}; expected one match, found {count}.")
    return updated


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: brand_amethyst.py PATH_TO_AMETHYST_CHECKOUT")

    root = Path(sys.argv[1]).resolve()
    gradle_file = root / "app_pojavlauncher" / "build.gradle"
    if not gradle_file.is_file():
        raise SystemExit(f"Amethyst Gradle file not found: {gradle_file}")

    source = gradle_file.read_text(encoding="utf-8")
    source = replace_once(
        source,
        r'(?m)^(\s*applicationId\s+)"org\.angelauramc\.amethyst"',
        r'\1"com.craftlauncher.android"',
        "applicationId",
    )

    replacements = {
        '"Amethyst (Debug)"': '"CraftLauncher (Debug)"',
        '"Amethyst"': '"CraftLauncher"',
        "'org.angelauramc.amethyst": "'com.craftlauncher.android",
    }
    for old, new in replacements.items():
        source = source.replace(old, new)

    # Fail rather than silently producing an incorrectly-branded APK.
    if '"CraftLauncher (Debug)"' not in source or '"CraftLauncher"' not in source:
        raise SystemExit("App-name branding checks failed.")
    if 'applicationId "com.craftlauncher.android"' not in source:
        raise SystemExit("Package-name branding check failed.")

    gradle_file.write_text(source, encoding="utf-8")
    print("CraftLauncher branding applied. Amethyst engine logic and account checks were not changed.")


if __name__ == "__main__":
    main()
